package com.training.example;

public class Main {

    public static void main(String[] args) {
        BanqueInteraction banqueInteraction = new BanqueInteraction();
        banqueInteraction.interaction();
    }
}
